const $ = (selector) => document.querySelector(selector);

// Theme toggle
const themeBtn = $("#themeBtn");
const savedTheme = localStorage.getItem("jsLabTheme");
if (savedTheme === "light") document.body.classList.add("light");
themeBtn.addEventListener("click", () => {
  document.body.classList.toggle("light");
  localStorage.setItem("jsLabTheme", document.body.classList.contains("light") ? "light" : "dark");
});

// Counter
let count = 0;
const countEl = $("#count");
function renderCount() {
  countEl.textContent = count;
}
$("#increase").addEventListener("click", () => { count++; renderCount(); });
$("#decrease").addEventListener("click", () => { count--; renderCount(); });
$("#reset").addEventListener("click", () => { count = 0; renderCount(); });

// Random number
$("#randomBtn").addEventListener("click", () => {
  const number = Math.floor(Math.random() * 100) + 1;
  $("#randomNumber").textContent = number;
});

// Grade checker
$("#gradeBtn").addEventListener("click", () => {
  const score = Number($("#score").value);
  const output = $("#gradeResult");
  if ($("#score").value === "" || score < 0 || score > 100) {
    output.textContent = "Enter a score from 0 to 100.";
  } else if (score >= 90) {
    output.textContent = `Grade A — excellent work!`;
  } else if (score >= 80) {
    output.textContent = `Grade B — great job!`;
  } else if (score >= 70) {
    output.textContent = `Grade C — keep practicing!`;
  } else if (score >= 60) {
    output.textContent = `Grade D — you can improve this.`;
  } else {
    output.textContent = `Grade F — review the concepts and try again.`;
  }
});

// Array explorer
let skills = ["HTML", "CSS", "JavaScript"];
const renderArray = () => {
  $("#arrayOutput").textContent = `[ ${skills.map(item => `"${item}"`).join(", ")} ]`;
};
renderArray();
$("#addItem").addEventListener("click", () => {
  skills.push(`JS${skills.length + 1}`);
  renderArray();
});
$("#removeItem").addEventListener("click", () => {
  if (skills.length) skills.pop();
  renderArray();
});
$("#mapItems").addEventListener("click", () => {
  skills = skills.map((item, index) => `${item}-${index + 1}`);
  renderArray();
});

// To-do app with localStorage
const TODO_KEY = "jsLabTasks";
let tasks = JSON.parse(localStorage.getItem(TODO_KEY) || "[]");
const saveTasks = () => localStorage.setItem(TODO_KEY, JSON.stringify(tasks));

function renderTasks() {
  const list = $("#todoList");
  list.innerHTML = "";
  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.className = `todo-item ${task.done ? "done" : ""}`;
    li.innerHTML = `
      <input type="checkbox" ${task.done ? "checked" : ""} aria-label="Complete task">
      <span>${escapeHtml(task.text)}</span>
      <button type="button" aria-label="Delete task">×</button>
    `;
    li.querySelector("input").addEventListener("change", () => {
      tasks[index].done = !tasks[index].done;
      saveTasks(); renderTasks();
    });
    li.querySelector("button").addEventListener("click", () => {
      tasks.splice(index, 1); saveTasks(); renderTasks();
    });
    list.appendChild(li);
  });
}
function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#039;"
  }[char]));
}
$("#todoForm").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = $("#todoInput");
  const text = input.value.trim();
  if (!text) return;
  tasks.push({ text, done: false });
  input.value = "";
  saveTasks(); renderTasks();
});
$("#clearTasks").addEventListener("click", () => {
  tasks = tasks.filter(task => !task.done);
  saveTasks(); renderTasks();
});
renderTasks();

// Object / profile lookup
const profiles = [
  { name: "Alex Morgan", role: "Frontend Developer", city: "Hyderabad", skills: ["HTML", "CSS", "JavaScript"] },
  { name: "Sam Lee", role: "UI Engineer", city: "Bengaluru", skills: ["JavaScript", "React", "Accessibility"] },
  { name: "Taylor Smith", role: "Web Designer", city: "Mumbai", skills: ["CSS", "Design", "UX"] }
];
function renderProfile() {
  const person = profiles[Number($("#profileSelect").value)];
  $("#profileOutput").innerHTML = `
    <strong>${person.name}</strong>
    <small>${person.role} • ${person.city}</small>
    <p>Skills: ${person.skills.join(" • ")}</p>
  `;
}
$("#profileSelect").addEventListener("change", renderProfile);
renderProfile();

// Calculator
let calcExpression = "";
const display = $("#calcDisplay");
document.querySelectorAll("[data-calc]").forEach(button => {
  button.addEventListener("click", () => {
    calcExpression += button.dataset.calc;
    display.value = calcExpression;
  });
});
$("#calculate").addEventListener("click", () => {
  try {
    if (!calcExpression) return;
    // Only arithmetic characters are allowed by the buttons above.
    const result = Function(`"use strict"; return (${calcExpression})`)();
    calcExpression = String(result);
    display.value = calcExpression;
  } catch {
    calcExpression = "";
    display.value = "Error";
  }
});
$("#clearCalc").addEventListener("click", () => {
  calcExpression = "";
  display.value = "0";
});

// Random quote
const quotes = [
  ["Programs must be written for people to read.", "Harold Abelson"],
  ["First, solve the problem. Then, write the code.", "John Johnson"],
  ["The only way to learn a new programming language is by writing programs in it.", "Dennis Ritchie"],
  ["Make it work, make it right, make it fast.", "Kent Beck"]
];
$("#quoteBtn").addEventListener("click", () => {
  const [quote, author] = quotes[Math.floor(Math.random() * quotes.length)];
  $("#quote").textContent = `“${quote}”`;
  $("#quoteAuthor").textContent = `— ${author}`;
});
