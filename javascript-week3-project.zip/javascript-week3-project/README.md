# JS Lab — JavaScript Week 3 Project

A GitHub-ready JavaScript project built around the concepts covered in the freeCodeCamp
**Learn JavaScript - Full Course for Beginners** video.

Video: https://youtu.be/PkZNo7MFNFg

## What is included

- Variables and data
- Functions and return values
- Arrays and array methods
- Objects and property access
- `if / else if / else`
- `Math.random()` and `Math.floor()`
- DOM manipulation
- Event listeners
- Forms and input handling
- Template literals
- Arrow functions
- `localStorage`
- Responsive HTML/CSS
- A working calculator
- Counter, random number generator, grade checker
- Array explorer
- Persistent to-do list
- Object/profile lookup
- Random quote generator
- Light/dark theme toggle

## Folder structure

```text
javascript-week3-project/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
```

## Run locally

Open `index.html` in a browser, or use VS Code Live Server.

No npm install is required.

## Publish to GitHub

```bash
git init
git add .
git commit -m "Complete JavaScript Week 3 project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/javascript-week3-project.git
git push -u origin main
```

## Note

This is an original implementation for demonstrating the course concepts. It does not reproduce
the instructor's source files.
